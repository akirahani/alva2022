<?php 
	$tit = "Lát nền đá tự nhiên";
	$des = "Lát nền đá tự nhiên";
	$key = "Lát nền đá tự nhiên";
	$link = $__URL__;
	$thumbs = $ROOT."uploads/thumbs.png";
?>