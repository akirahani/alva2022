<?php 
	$tit = "Ốp lát phòng tắm đá tự nhiên";
	$des = "Ốp lát phòng tắm đá tự nhiên";
	$key = "Ốp lát phòng tắm đá tự nhiên";
	$link = $__URL__;
	$thumbs = $ROOT."uploads/thumbs.png";
?>