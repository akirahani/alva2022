<?php 
	$tit = "Ốp lát trụ cột đá tự nhiên";
	$des = "Ốp lát trụ cột đá tự nhiên";
	$key = "Ốp lát trụ cột đá tự nhiên";
	$link = $__URL__;
	$thumbs = $ROOT."uploads/thumbs.png";
?>