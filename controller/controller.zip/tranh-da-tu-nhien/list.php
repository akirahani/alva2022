<?php 
	$tit = "Tranh đá tự nhiên";
	$des = "Tranh đá tự nhiên";
	$key = "Tranh đá tự nhiên";
	$link = $__URL__;
	$thumbs = $ROOT."uploads/thumbs.png";
?>