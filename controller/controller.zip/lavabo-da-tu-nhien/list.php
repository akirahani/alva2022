<?php 
	$tit = "Lavabo đá tự nhiên";
	$des = "Lavabo đá tự nhiên";
	$key = "Lavabo đá tự nhiên";
	$link = $__URL__;
	$thumbs = $ROOT."uploads/thumbs.png";
?>