<?php 
	$tit = "Ốp lát cầu thang đá tự nhiên";
	$des = "Ốp lát cầu thang đá tự nhiên";
	$key = "Ốp lát cầu thang đá tự nhiên";
	$link = $__URL__;
	$thumbs = $ROOT."uploads/thumbs.png";
?>